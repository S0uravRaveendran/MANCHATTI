from django.contrib import admin


from .models import Category,Product,Testimonials,Specials,Gallery,Heroimg

admin.site.register(Category),
admin.site.register(Product),
admin.site.register(Testimonials),
admin.site.register(Specials),
admin.site.register(Gallery),
admin.site.register(Heroimg)
