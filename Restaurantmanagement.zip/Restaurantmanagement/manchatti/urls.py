"""
URL configuration for Restaurantmanagement project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('base',views.base,name='base'),
    path('menu',views.menu,name='menu'),
    path('specials',views.specials,name='specials'),
    path('gallery',views.gallery,name='gallery'),
    path('contactus',views.contactUs,name='contactus'),
    #path('signup',views.signup,name='signup'),
    path('register',views.register_request,name='one'),

    path('login',views.login,name='login'),
    #path('category',views.category,name='category'),
    path('logout',views.logout,name='logout'),
    path('product/<int:category_id>',views.product,name='product'),
    path('product_details/<int:id>',views.product_details,name='product_details'),
    path('review',views.review,name='review'),
  

    #admin side

    path('adminlogin',views.adminlogin,name='adminlogin'),
    path('adminhome',views.adminhome,name='adminhome'),
    path('add_category',views.add_category,name='addcategory'),
    path('edit_category/<int:id>',views.edit_category,name='editcategory'),
    path('delete_category/<int:id>',views.delete_category,name='delete_category'),
    path('add_product',views.add_product,name='addproduct'),
    path('edit_product/<int:id>',views.edit_product,name='editproduct'),
    path('delete_product/<int:id>',views.delete_product,name='delete_product'),
    path('add_testimonials',views.add_testimonials,name='add_testimonial'),
    path('edit_testimonials/<int:id>',views.edit_testimonials,name='edit_testimonial'),
    path('delete_testimonials/<int:id>',views.delete_testimonials,name='delete_testimonials'),
    path('add_gallery',views.add_gallery,name='add_gallery'),
    path('delete_gallery/<int:id>',views.delete_gallery,name='delete_gallery'),
    path('add_specials',views.add_specials,name='add_specials'),
    path('edit_specials/<int:id>',views.edit_specials,name='edit_specials'),
    path('delete_specials/<int:id>',views.delete_specials,name='delete_specials'),
    path('change_hero',views.change_hero,name='change_hero'),
    path('delete_hero/<int:id>',views.delete_hero,name='delete_hero'),
    path('view_review',views.view_review,name='view_review'),
    path('delete_review/<int:id>',views.delete_review,name='delete_review'),
    path('change_logo',views.change_logo,name='change_logo'),
    path('delete_logo/<int:id>',views.delete_logo,name='delete_logo'),
    
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
