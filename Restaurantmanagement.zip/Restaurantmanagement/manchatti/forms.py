from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.forms import ModelForm
from .models import Category,Testimonials,Gallery,Product,Specials,Review,Heroimg,Logoimg

# Create your forms here.

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)
	class Meta:
		model = User
		fields = ("username", "email")
		widgets = {
		'username': forms.TextInput(),
		'email': forms.TextInput(),
		#'password': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'password'}),

		}
	def __init__(self, *args, **kargs):
		super(NewUserForm, self).__init__(*args, **kargs)
		del self.fields['password2']





class CategoryForm(ModelForm):
	class Meta:
		model = Category
		fields = ('categoryname', 'category_description', 'category_image')
		widgets = {
		'categoryname': forms.TextInput(attrs={'class': 'form-control' }),
		'category_description': forms.TextInput(attrs={'class': 'form-control'}),
		'category_image': forms.FileInput(),
		}


	

class TestimonialForm(ModelForm):
	class Meta:
		model = Testimonials
		fields = ('username', 'user_photo', 'content')
		widgets = {
		'username': forms.TextInput(attrs={'class': 'form-control' }),
		'user_photo': forms.FileInput(),
		'content': forms.TextInput(attrs={'class': 'form-control'})

		}

class GalleryForm(ModelForm):
	class Meta:
		model = Gallery
		fields = '__all__'
		widgets = {
		'image' : forms.FileInput(),
		}



class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = ('productname', 'product_description', 'product_image', 'product_price', 'category')
        
        widgets = {
            'productname': forms.TextInput(attrs={'class': 'forms-control', 'placeholder': 'Enter Product'}),
            'product_description': forms.TextInput(attrs={'class': 'forms-control', 'placeholder': 'Enter description'}),
            'product_image': forms.FileInput(),
            'product_price': forms.TextInput(attrs={'class': 'forms-control', 'placeholder': 'Enter Price'}),
            'category': forms.Select(attrs={'class': 'forms-control'}),  # Use a Select widget
        }

    def __init__(self, *args, **kwargs):
        super(ProductForm, self).__init__(*args, **kwargs)
        
        # Populate the category dropdown with available categories
        self.fields['category'].queryset = Category.objects.all()
        self.fields['category'].empty_label = "Select a category"


class SpecialForm(ModelForm):
	class Meta:
		model = Specials
		fields = ('itemname', 'item_image', 'item_description')
		widgets = {
		'itemname': forms.TextInput(attrs={'class': 'form-control' }),
		'item_image': forms.FileInput(),
		'item_description': forms.TextInput(attrs={'class': 'form-control'})
		}

class ReviewForm(ModelForm):
	class Meta:
		model = Review
		fields = ('user', 'email', 'phone','comment')
		widgets = {
		'user': forms.TextInput(attrs={'class': 'form-control' }),
		'email': forms.TextInput(attrs={'class': 'form-control' }),
		'phone': forms.TextInput(attrs={'class': 'form-control'}),
		'comment': forms.TextInput(attrs={'class': 'form-control'})

		}

class HeroForm(ModelForm):
	class Meta:
		model = Heroimg
		fields = '__all__'
		widgets = {
		'hero_image' : forms.FileInput(),
		}

class LogoForm(ModelForm):
	class Meta:
		model = Logoimg
		fields = '__all__'
		widgets = {
		'logo_image' : forms.FileInput(),
		}