from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth
from .forms import NewUserForm,CategoryForm,TestimonialForm,GalleryForm,ProductForm,SpecialForm,ReviewForm,HeroForm,LogoForm
from django.contrib.auth import login
from django.contrib import messages
from .models import Category,Product,Review,Testimonials,Specials,Gallery,Specials,Heroimg,Logoimg
import os

def home(request):
     categories = Category.objects.all().values()
     testimonials = Testimonials.objects.all()
     product_list = Product.objects.all()
     specials = Specials.objects.all()
     gallery = Gallery.objects.all()
     hero_img = Heroimg.objects.all()
     logo_img = Logoimg.objects.all()
     
     form = ReviewForm()    
     context = {
     'categories': categories, 
     'testimonials' : testimonials,
     'products' : product_list,
     'specials' : specials,
     'gallery' : gallery,
     'hero_img' : hero_img,
     'logo_img' : logo_img,
     'form' : form
     
      }

     if request.method=="POST":
        form = ReviewForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()  
            
  
     return render(request,'homepage.html',context)
def base(request):
        logo_img = Logoimg.objects.all()
        context = {
           'logo_img' : logo_img,
        }
        return render(request,'base.html',context)
        

def login(request):
    if request.method == 'POST':
        user = auth.authenticate(username=request.POST['username'],password = request.POST['password'])
        if user is not None:
            auth.login(request,user)
            return redirect('home')
        else:
            return render (request,'login.html', {'error':'Username or password is incorrect!'})
    else:
        return render(request,'login.html')

def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        print("here")
        if form.is_valid():
            print("y")
            user = form.save()
            auth.login(request, user)
            messages.success(request, "Registration successful." )
            return redirect("login")
    messages.error(request, "Unsuccessful registration. Invalid information.")
    form = NewUserForm()
    return render (request=request, template_name="signup.html", context={"form":form})

def logout(request):
    auth.logout(request)
    return redirect('home')
    return render(request,'homepage.html')

def menu(request):
    categories = Category.objects.all().values()
    product_list = Product.objects.all()
    context = {
        'categories': categories, 
    
        'products' : product_list
         
    }
    return render(request,'menu.html',context)
def specials(request):
    specials = Specials.objects.all()
    context = {
        'specials' : specials,
    }
    return render(request,'specials.html',context)
def gallery(request):
    gallery = Gallery.objects.all()
    context = {
        'gallery' : gallery,
    }
    return render(request,'gallery.html',context)
def contactUs(request):
    return render(request,'contactus.html')
def product(request,category_id):
     
    product_list = Product.objects.filter(category_id=category_id)
 
    context = {
        'products' : product_list
    }
    return render(request,'product.html',context)

def product_details(request,id):
    products = Product.objects.filter(id=id)
    context = {
        'products' : products
    }
    return render(request,'product_details.html',context)

def review(request):
    
    form = ReviewForm()
    if request.method=="POST":
        form = ReviewForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()  
    context = {
           'form' : form 
    }
        
    return render(request,'review.html',context)


#admin side
def adminlogin(request):
     if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username = username, password = password)
        if user is not None and user.is_staff == True:
            auth.login(request,user)
            messages.success(request, 'You are Logged in')
            return redirect('adminhome')
        
        else:
            messages.error(request,'Your Username or Password is incorrect')
            return redirect('adminlogin')
        return
     else:
        return render(request,'adminlogin.html')
 

def adminhome(request):
    return render(request,'adminhome.html')

def add_category(request):
    form = CategoryForm()
    if request.method=="POST":
        form = CategoryForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()
            return redirect('addcategory')

    categories = Category.objects.all().values()
    context = {
      'form': form,
      'categories': categories 
       } 
    return render(request,'add_category.html',context)
    
def edit_category(request, id):
    categories = Category.objects.get(id=id)
    form = CategoryForm(instance=categories)
    context = {
            # 'categories': categories,
            'form': form
            }
    if request.method == 'POST':
        
        form = CategoryForm(request.POST,request.FILES,instance=categories)
        if form.is_valid():
            form.save()
            return redirect('addcategory')

    return render(request, 'edit_category.html', context)

def delete_category(request, id):
    categories = Category.objects.get(id=id)
    categories.delete()
    return redirect('addcategory')
   


def add_product(request):
    
    form = ProductForm()
    if request.method=="POST":
        form = ProductForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()
            return redirect('addproduct')

    products = Product.objects.all().values()
    context = {
      'products': products,
      'form' : form
       } 
    return render(request,'add_product.html',context)

def edit_product(request, id):
    products = Product.objects.get(id=id)
    form = ProductForm(instance=products)
    context = {
            
            'form': form
            }
    if request.method == 'POST':
        
        form = ProductForm(request.POST,request.FILES,instance=products)
        if form.is_valid():
            form.save()
            return redirect('addproduct')

    return render(request, 'edit_product.html', context)


def delete_product(request, id):
    products = Product.objects.get(id=id)
    products.delete()
    return redirect('addproduct')
   

def add_testimonials(request):
    form = TestimonialForm()
    if request.method=="POST":
        form = TestimonialForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()
            return redirect('add_testimonial')
    testimonials = Testimonials.objects.all().values()
    context = {
        'testimonials' : testimonials,
        'form' : form,

    }
    return render(request,'add_testimonials.html',context)

def edit_testimonials(request, id):
    testimonials = Testimonials.objects.get(id=id)

    form = TestimonialForm(instance=testimonials)
    context = {
            'form': form
            }
    if request.method == 'POST':
        form = TestimonialForm(request.POST,request.FILES,instance=testimonials)
        if form.is_valid():
            form.save()
            return redirect('add_testimonial')
    
    return render(request, 'edit_testimonials.html', context)


def delete_testimonials(request, id):
    testimonials = Testimonials.objects.get(id=id)
    testimonials.delete()
    return redirect('add_testimonial')

def add_gallery(request):
    form = GalleryForm()
    if request.method == 'POST':
        form = GalleryForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('add_gallery')
        
    gallery = Gallery.objects.all().values()
    context = {
            'gallery': gallery,
            'form' : form
            }

    return render(request, 'add_gallery.html', context)

def delete_gallery(request, id):
    gallery = Gallery.objects.get(id=id)
    gallery.delete()
    return redirect('add_gallery')


def add_specials(request):
    form = SpecialForm()
    specials = Specials.objects.all().values()
    if request.method == 'POST':
        form = SpecialForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('add_specials')
    
    context = {
        'specials' : specials,
        'form' : form
    }
    return render(request, 'add_specials.html', context)


def edit_specials(request, id):
    specials = Specials.objects.get(id=id)
    form = SpecialForm(instance=specials)
    context = {
        'form' : form
    }

    if request.method == 'POST':
        form = SpecialForm(request.POST,request.FILES,instance=specials)
        if form.is_valid():
            form.save()
            return redirect('add_specials')

    return render(request, 'add_specials.html', context)

def delete_specials(request, id):
    specials = Specials.objects.get(id=id)
    specials.delete()
    return redirect('add_specials')

def change_hero(request):
    form = HeroForm()
    hero_img = Heroimg.objects.all()
    if request.method == 'POST':
        form = HeroForm(request.POST,request.FILES)
        if form.is_valid:
            form.save()
            return redirect('change_hero')
    context = {
        'hero_img' : hero_img,
        'form' : form
    }
    return render(request,'change_hero.html',context)


def delete_hero(request, id):
    hero_img = Heroimg.objects.get(id=id)
    hero_img.delete()
    return redirect('change_hero')

def view_review(request):
    review = Review.objects.all().values()
    context = {
        'review' : review
    }
    return render(request,'view_review.html',context)

def delete_review(request,id):
    review = Review.objects.get(id=id)
    review.delete()
    return redirect('view_review')

def change_logo(request):
    form = LogoForm()
    logo_img = Logoimg.objects.all()
    if request.method == 'POST':
        form = LogoForm(request.POST,request.FILES)
        if form.is_valid:
            form.save()
            return redirect('change_logo')
    context = {
        'logo_img' : logo_img,
        'form' : form
    }
    return render(request,'change_logo.html',context)


def delete_logo(request, id):
    logo_img = Logoimg.objects.get(id=id)
    logo_img.delete()
    return redirect('change_logo')