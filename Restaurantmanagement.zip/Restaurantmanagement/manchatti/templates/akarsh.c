#include <stdio.h>
 int main()
 {
    printf("gello");
    return 0;
 }