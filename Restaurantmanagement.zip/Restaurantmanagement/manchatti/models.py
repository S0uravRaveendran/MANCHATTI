from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    categoryname = models.CharField(max_length=255)
    category_description = models.CharField(max_length=500)
    category_image = models.ImageField(upload_to ='category')

    def __str__(self):
        return f"{self.categoryname}"


class Product(models.Model):
    category = models.ForeignKey('Category', on_delete=models.CASCADE)
    productname = models.CharField(max_length=250)
    #slug = models.SlugField(unique=True ,null=True)
    product_description = models.CharField(max_length=500)
    product_price = models.CharField(max_length=500,null=True)
    product_image = models.ImageField(upload_to ='' , null=True)
    
    
    def __str__(self):
        return f"{self.productname}"

class Review(models.Model):
    user = models.CharField(max_length=200)
    email = models.EmailField(max_length=50)
    phone = models.CharField(max_length=10 ,null=True)
    comment = models.CharField(max_length=500)

class Testimonials(models.Model):
    username = models.CharField(max_length=200)
    user_photo = models.ImageField(upload_to = 'testimonials',null=True) 
    content = models.CharField(max_length=200)
    
class Specials(models.Model):
    itemname = models.CharField(max_length=200)
    item_description = models.CharField(max_length=500)
    item_image = models.ImageField(upload_to ='' , null=True)

    def __str__(self):
        return f"{self.itemname}"

class Gallery(models.Model):
    image = models.ImageField(upload_to='')
    
class Heroimg(models.Model):
    hero_img = models.ImageField(upload_to='')

class Logoimg(models.Model):
    logo_img = models.ImageField(upload_to='')